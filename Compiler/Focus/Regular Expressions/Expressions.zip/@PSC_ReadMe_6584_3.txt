Title: Algebraic Expressions, Conversion and Evaluation with C
Description: This tutorial is a Complete Guide to Algebraic Expressions, Different expression notations like Prefix, Postfix and Infix and Evaluation of the expressions. How to convert an expression from one notation to another? How to evaluate Algebraic Expression in Computers?
Each and every concept is backed by Algorithms, illustrative examples and a programs in C to help new programmers understand concepts more clearly.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6584&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
